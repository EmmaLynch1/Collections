/*
public class Vote{
  private int votedID;
  private Vote(int votedID){
    this.votedID=votedID;
  }
  public int getVotedID(){
    return votedID;
  }
}
*/
