import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class VotingSystem{
  private ArrayList<Candidate> candidates;
  private HashMap<Integer, Integer>votes;
  private HashSet<Integer> votedCandidates;
  private Queue<Winner> winnersQueue;

  

  public VotingSystem(){
    candidates = new ArrayList<Candidate>();
    votes= new HashMap<Integer, Integer>();
    votedCandidates = new HashSet<Integer>();
    winnersQueue = new LinkedList<Winner>();
  
  
  }
  public void addCandidate(Candidate candidate){
    candidates.add(candidate);
  }
  public void displayCandidates() {
    System.out.println("Candidates:");
    for (Candidate candidate : candidates) {
        System.out.println(candidate);
  }
}
  public void voteForCandidate(int ID){
    boolean validCandidate=false;
    for(Candidate candidate: candidates){
      if (candidate.getId() == ID) {
        votes.put(ID, votes.getOrDefault(ID, 0) + 1);
        votedCandidates.add(ID);
        validCandidate = true;
        candidate.addVote();
        System.out.println("Vote registered "+ID);
        break;
    }
  }
    if(!validCandidate){
      System.out.println("not a valid ID, try again. ");
    }
  }
  // Getter method to get total votes
  public int getTotalVotes() {
      int totalVotes = 0;
      for (Candidate candidate : candidates) {
          totalVotes += candidate.getVotes();
      }
      return totalVotes;
  }
    public Queue<Winner> getWinnersQueue() {
      int maxVotes = 0;
      // Find candidates with maximum votes
      for (Candidate candidate : candidates) {
          int candidateVotes = votes.getOrDefault(candidate.getId(), 0);
          if (candidateVotes > maxVotes) {
              maxVotes = candidateVotes;
              winnersQueue.clear();
              winnersQueue.add(new Winner(candidate.getId(), candidate.getFirstName(), candidate.getLastName(), candidate.getAge(), candidateVotes));
          } else if (candidateVotes == maxVotes) {
              winnersQueue.add(new Winner(candidate.getId(), candidate.getFirstName(), candidate.getLastName(), candidate.getAge(), candidateVotes));
          }
      }
      return winnersQueue;
}
}

