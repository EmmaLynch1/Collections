import java.util.Scanner;
import java.util.InputMismatchException;

public class Main {
  public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
    VotingSystem votingSystem=new VotingSystem();
  int numCandidates= 0;
    while(numCandidates<=0){
      try{
  
    //ask for number of candidates
    System.out.print("Enter number of candidates(positive integer): ");
    numCandidates= scanner.nextInt();
    scanner.nextLine();
        if(numCandidates <=0){
          System.out.println("Invalid Input, only positive");
        }
      }
        catch(InputMismatchException e) {
        System.out.println("Invalid input. Please enter a positive integer.");
        scanner.nextLine();
      }
    }
  //input the candidate details
for(int i =1; i<=numCandidates;i++){
  String firstName = "";
  while (firstName.isEmpty()|| !firstName.matches("[a-zA-Z]+")) {
      System.out.print("Enter the first name of candidate " + i + ": ");
      firstName = capitalizeFirstLetter(scanner.nextLine().trim());
      if (firstName.isEmpty()|| !firstName.matches("[a-zA-Z]+")) {
          System.out.println("Please enter a valid first name.");
      }
  }
    String lastName = "";
   while (true) {
       System.out.print("Enter the last name of candidate " + i + ": ");
       lastName = capitalizeFirstLetter(scanner.nextLine().trim());
       if (!lastName.isEmpty() && lastName.matches("[a-zA-Z]+")) {
           break; // Break the loop if a valid last name is entered
       }
       System.out.println("Please enter a valid last name");
     }
      int age = 0;
      boolean validAge = false;
      while (!validAge) {
          try {
              System.out.print("Enter the age of candidate " + i + " (between 1 and 150): ");
              age = scanner.nextInt();
              scanner.nextLine();
              if (age < 1 || age > 150) {
                  System.out.println("Invalid input. Age must be between 1 and 150.");
              } else {
                  validAge = true;
              }
          } catch (InputMismatchException e) {
              System.out.println("Invalid input. Please enter a valid age.");
              scanner.nextLine(); 
          }
      }
  votingSystem.addCandidate(new Candidate(i, firstName, lastName, age, 0));
    }
    //voting process
    while(true){
      votingSystem.displayCandidates();
      System.out.print("Enter ID of the candidate you want to vote for, or 0 to exit: ");
      int candidateId = scanner.nextInt();
          if (candidateId == 0) {
              break;
            } else if (candidateId < 1 || candidateId > numCandidates) {
                System.out.println("Please enter a valid ID.");
            } else {
                votingSystem.voteForCandidate(candidateId);
                System.out.println();
            }
    }
    //display the winner if one vote registered
      if (votingSystem.getTotalVotes() > 0) {
                  System.out.println("Winner(s):");
                  for (Winner winner : votingSystem.getWinnersQueue()) {
                      System.out.println(winner);
                  }
              } else {
                  System.out.println("No votes registered. Exiting.");
              }
          }
    // Helper method to capitalize the first letter of a string
        private static String capitalizeFirstLetter(String str) {
            if (str.isEmpty()) {
                return str;
            }
            return Character.toUpperCase(str.charAt(0)) + str.substring(1);
        }
    }


