import java.util.ArrayList;
import java.util.HashMap;
public class Candidate{
  private int id;
  private String firstName;
  private String lastName;
  private int votes;
  private int age;

  //create blueprint for the candidate
  public Candidate(int id, String firstName, String lastName, int age, int votes){
    this.id=id;
    this.firstName=firstName;
    this.lastName=lastName;
    this.votes=0;
    this.age=age;
  }
  public int getId() {
      return id;
  }

  public String getFirstName() {
      return firstName;
  }

  public String getLastName() {
      return lastName;
  }

  public int getAge() {
      return age;
  }

  public int getVotes() {
      return votes;
  }

  public void addVote() {
      votes++;
  }
  //method to convert all data to string type
  public String toString(){
    return" ID: "+id +  ", Name: " + firstName + " " + lastName + ", Age: " + age + ", Votes: " + votes;
  }
}
