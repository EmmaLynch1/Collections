import java.util.*;

public class Main {
//for sum
   public static int calculateSum(LinkedList<Integer> numbers) {
    int sum = 0;
    for (int num : numbers) {
      sum += num;
    }
    return sum;
  }
  public static void main(String[] args) {
    //ArrayList of clothing articles
    System.out.println("ARRAY LIST");
    System.out.println(" ");
    ArrayList<String> clothingArticles= new ArrayList<String>();
    //function to add clothing articles to arraylist
    clothingArticles.add("Pants");
    clothingArticles.add("Shirt");
    clothingArticles.add("Socks");
    clothingArticles.add("Shoes");
    clothingArticles.add("Underwear");
    //function to remove clothing from arraylist
    clothingArticles.remove("Pants");
    //function to determine if contains something specific
    System.out.println("Do we have socks? " +clothingArticles.contains("Socks"));
    //function to get size of list
    System.out.println("Number of clothing articles: "+clothingArticles.size());
    //clear the list
    clothingArticles.clear();

    System.out.println(" ");
    System.out.println("LinkedList");
    System.out.println(" ");
    //LinkedList of random integers
    LinkedList<Integer> numbers= new LinkedList<Integer>();
    //function to add numbers
    numbers.add(10);
    numbers.add(15);
    numbers.add(20);
    numbers.add(25);
    //function to remove first number
    numbers.removeFirst();
    //function to remove a number from list
    numbers.remove(2);
    //function for getting first number of list
    System.out.println("First number: "+ numbers.getFirst());
    //function for checking if list is empty
    System.out.println("is linked list empty? " + numbers.isEmpty());
    //calculate sum
    int sum= calculateSum(numbers);
    System.out.println("Sum of numbers in linked list: " + sum);

    System.out.println(" ");
    System.out.println("HASHSET");
    System.out.println(" ");
    //double hashset
    Set<Double> doubleSet= new HashSet<Double>();
    //function to add doubles to set
    doubleSet.add(10.5);
    doubleSet.add(20.7);
    doubleSet.add(30.3);
    doubleSet.add(40.9);
    System.out.println("Hashset: " +doubleSet);
    //check if hashset is empty
     System.out.println("Is HashSet empty? " + doubleSet.isEmpty());
    //create copy of current hashet
    Set<Double> copySet = new HashSet<Double>(doubleSet);
    //remove eleemnts greater than 30
    Set<Double> tempSet = new HashSet<Double>();
    for (Double value : doubleSet) {
        if (value <= 30) {
            tempSet.add(value);
        }
    }
    doubleSet = tempSet;
//display elements
      System.out.println("New Hashset: "+doubleSet);

    System.out.println(" ");
    System.out.println("QUEUE");
    System.out.println(" ");
  //Queue of fruits
    Queue<String> fruitQueue = new ArrayDeque<String>();
    //function for adding fruits to queue
     fruitQueue.add("Apple");
     fruitQueue.add("Banana");
     fruitQueue.add("Strawberry");
     fruitQueue.add("Orange");
     fruitQueue.add("Grapes");

     // Removing a fruit from Queue
      System.out.println("Removed from Queue: " + fruitQueue.poll());
    //function for checking if queue is empty
     System.out.println("Is Queue empty? " + fruitQueue.isEmpty());
    //function for getting first element of queue
     System.out.println("First fruit of Queue: " + fruitQueue.peek());
    //converting queue to array.
      String[] fruitArray = fruitQueue.toArray(new String[0]);
        System.out.println("Array of Queue: " + Arrays.toString(fruitArray));

System.out.println(" ");
    System.out.println("MAP");
    System.out.println(" ");
    //Map of students with grades
    Map<String, Integer> studentGrades = new HashMap<String, Integer>(); 
    //adding students and grades to the map
        studentGrades.put("Olive", 85);
        studentGrades.put("Emma", 93);
        studentGrades.put("Bob", 78);
        studentGrades.put("Emily", 97);
    //function to remove a student 
    studentGrades.remove("Bob");
    //function to check if map contains a student
    System.out.println("Does Map contain key 'Emma'? " + studentGrades.containsKey("Emma"));
    //function to print all students w their grades
    printStudentGrades(studentGrades);

    //function to clear map
    studentGrades.clear();
  }
  // Function to print all students with their grades
  private static void printStudentGrades(Map<String, Integer> studentGrades) {
      System.out.println("Students with their grades:");
      for (Map.Entry<String, Integer> entry : studentGrades.entrySet()) {
          System.out.println(entry.getKey() + ": " + entry.getValue());
            }
  }
}